-- MUTEBI WAISEDHA STUDIOS: cloud sync for franchises and continuity notes
-- Run this in the same Supabase project after the earlier MWS migration.
create table if not exists public.studio_records (
  record_type text not null check (record_type in ('franchise','continuity')),
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (record_type, id)
);
alter table public.studio_records enable row level security;
drop policy if exists "Public can view MWS studio records" on public.studio_records;
create policy "Public can view MWS studio records" on public.studio_records
  for select to anon, authenticated using (true);
drop policy if exists "MWS creator inserts studio records" on public.studio_records;
create policy "MWS creator inserts studio records" on public.studio_records
  for insert to authenticated with check ((auth.jwt()->'app_metadata'->>'studio_role') = 'creator');
drop policy if exists "MWS creator updates studio records" on public.studio_records;
create policy "MWS creator updates studio records" on public.studio_records
  for update to authenticated
  using ((auth.jwt()->'app_metadata'->>'studio_role') = 'creator')
  with check ((auth.jwt()->'app_metadata'->>'studio_role') = 'creator');
drop policy if exists "MWS creator deletes studio records" on public.studio_records;
create policy "MWS creator deletes studio records" on public.studio_records
  for delete to authenticated using ((auth.jwt()->'app_metadata'->>'studio_role') = 'creator');
