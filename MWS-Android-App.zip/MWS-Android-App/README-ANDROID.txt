MUTEBI WAISEDHA STUDIOS — ANDROID APK PROJECT

WHAT THIS IS
This project packages the studio website as an Android app using Capacitor. It preserves the existing stories, character editor, franchise editor, continuity desk, creator login, image uploads and Supabase connection, with a redesigned dark/gold mobile interface.

IMPORTANT BEFORE BUILDING
1. Keep your current website repository and its index.html intact. This is a separate Android project.
2. Your Supabase project URL and public publishable key are configured in www/index.html. Never add a service_role/secret key.
3. Run MWS-Android-Supabase-Update.sql in your existing Supabase SQL Editor to add the cloud table for franchises and continuity notes.
4. Existing browser-local records are not automatically uploaded merely by installing the APK. Sign into Creator Studio and use the cloud import option with a fresh mws-backup.json. Cloud sync is intended for stories, characters, franchises and continuity notes; private character notes remain local.

BUILDING AN APK FROM AN ANDROID PHONE (FREE WORKFLOW)
A. Create a new GitHub repository named mws-android-app. Do not replace the live website repository with this project.
B. Extract this ZIP on your phone using ZArchiver or another ZIP tool. Upload the project files/folders to the new repository. Include the .github/workflows/build-apk.yml file if you use the included workflow.
C. In the new GitHub repository, open Actions and run “Build MWS Android APK”, or push a change to trigger it.
D. When the workflow succeeds, open its run, scroll to Artifacts, and download mws-debug-apk. Extract the artifact ZIP to get app-debug.apk.
E. Open app-debug.apk on your phone and allow installation from that source if Android asks.

The APK is a debug build for personal testing, not a Play Store release. Play Store distribution later requires a signed release build and Google Play account setup.

BUILD ENVIRONMENT
GitHub Actions uses Node 20, Java 21 and Gradle to create the Android project and compile the debug APK. You do not need Android Studio on your phone.

KNOWN LIMITATIONS
- Network access is required for Supabase, the Supabase JS CDN and Google Fonts.
- Public stories/characters/franchises/continuity can be read by visitors according to the database policies. Creator writes require Supabase authentication with app_metadata.studio_role = creator.
- This build has not been run against your live Supabase project from this environment. Verify login, data sync and image uploads before relying on it.
